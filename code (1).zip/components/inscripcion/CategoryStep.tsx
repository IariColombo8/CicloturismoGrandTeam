"use client"

import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

interface CategoryStepProps {
  formData: any
  updateFormData: (data: any) => void
}

export default function CategoryStep({ formData, updateFormData }: CategoryStepProps) {
  return (
    <div className="space-y-6">
      {/* Category Selection */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-yellow-400">Categoría de Participación</h3>

        <div className="space-y-2">
          <Label htmlFor="categoria" className="text-gray-300">
            Categoría <span className="text-red-500">*</span>
          </Label>
          <Select value={formData.categoria} onValueChange={(value) => updateFormData({ categoria: value })}>
            <SelectTrigger className="bg-zinc-900 border-yellow-400/30 text-white">
              <SelectValue placeholder="Selecciona una categoría" />
            </SelectTrigger>
            <SelectContent className="bg-zinc-900 border-yellow-400/30">
              <SelectItem value="libre">Libre - Disfruta el recorrido a tu ritmo</SelectItem>
              <SelectItem value="competitivo">Competitivo - Desafía tus límites</SelectItem>
              <SelectItem value="familiar">Familiar - Para toda la familia</SelectItem>
            </SelectContent>
          </Select>
          <p className="text-sm text-gray-500">
            {formData.categoria === "libre" && "Categoría recreativa para disfrutar el paisaje sin presión de tiempo."}
            {formData.categoria === "competitivo" &&
              "Para ciclistas experimentados que buscan un desafío cronometrado."}
            {formData.categoria === "familiar" && "Recorrido adaptado para grupos familiares con niños."}
          </p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="tallaCamiseta" className="text-gray-300">
            Talla de Camiseta <span className="text-red-500">*</span>
          </Label>
          <Select value={formData.tallaCamiseta} onValueChange={(value) => updateFormData({ tallaCamiseta: value })}>
            <SelectTrigger className="bg-zinc-900 border-yellow-400/30 text-white">
              <SelectValue placeholder="Selecciona tu talla" />
            </SelectTrigger>
            <SelectContent className="bg-zinc-900 border-yellow-400/30">
              <SelectItem value="xs">XS - Extra Small</SelectItem>
              <SelectItem value="s">S - Small</SelectItem>
              <SelectItem value="m">M - Medium</SelectItem>
              <SelectItem value="l">L - Large</SelectItem>
              <SelectItem value="xl">XL - Extra Large</SelectItem>
              <SelectItem value="xxl">XXL - Double Extra Large</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Medical Information */}
      <div className="space-y-4 pt-6 border-t border-yellow-400/20">
        <h3 className="text-lg font-semibold text-yellow-400">Información Médica</h3>

        <div className="space-y-2">
          <Label htmlFor="tipoSangre" className="text-gray-300">
            Tipo de Sangre <span className="text-red-500">*</span>
          </Label>
          <Select value={formData.tipoSangre} onValueChange={(value) => updateFormData({ tipoSangre: value })}>
            <SelectTrigger className="bg-zinc-900 border-yellow-400/30 text-white">
              <SelectValue placeholder="Selecciona tu tipo de sangre" />
            </SelectTrigger>
            <SelectContent className="bg-zinc-900 border-yellow-400/30">
              <SelectItem value="A+">A+</SelectItem>
              <SelectItem value="A-">A-</SelectItem>
              <SelectItem value="B+">B+</SelectItem>
              <SelectItem value="B-">B-</SelectItem>
              <SelectItem value="AB+">AB+</SelectItem>
              <SelectItem value="AB-">AB-</SelectItem>
              <SelectItem value="O+">O+</SelectItem>
              <SelectItem value="O-">O-</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="alergias" className="text-gray-300">
            Alergias (si aplica)
          </Label>
          <Textarea
            id="alergias"
            value={formData.alergias}
            onChange={(e) => updateFormData({ alergias: e.target.value })}
            placeholder="Describe cualquier alergia que tengamos que conocer"
            className="bg-zinc-900 border-yellow-400/30 text-white min-h-[80px]"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="condicionesMedicas" className="text-gray-300">
            Condiciones Médicas (si aplica)
          </Label>
          <Textarea
            id="condicionesMedicas"
            value={formData.condicionesMedicas}
            onChange={(e) => updateFormData({ condicionesMedicas: e.target.value })}
            placeholder="Describe cualquier condición médica relevante (diabetes, asma, etc.)"
            className="bg-zinc-900 border-yellow-400/30 text-white min-h-[80px]"
          />
        </div>

        <div className="bg-yellow-400/10 border border-yellow-400/30 rounded-lg p-4">
          <p className="text-sm text-gray-300">
            <strong className="text-yellow-400">Nota:</strong> Esta información es confidencial y solo se utilizará en
            caso de emergencia médica durante el evento.
          </p>
        </div>
      </div>
    </div>
  )
}
