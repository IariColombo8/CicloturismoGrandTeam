"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, XCircle, ExternalLink } from "lucide-react"
import Image from "next/image"

interface InscripcionDetailModalProps {
  inscripcion: any
  isOpen: boolean
  onClose: () => void
  onApprove: (id: string) => void
  onReject: (id: string) => void
}

export default function InscripcionDetailModal({
  inscripcion,
  isOpen,
  onClose,
  onApprove,
  onReject,
}: InscripcionDetailModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-zinc-900 border-yellow-400/30 text-white max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold gradient-text">Detalle de Inscripción</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Status */}
          <div className="flex items-center justify-between p-4 bg-black/50 rounded-lg">
            <span className="text-gray-400">Estado</span>
            <Badge
              className={
                inscripcion.estado === "aprobado"
                  ? "bg-green-500/20 text-green-500"
                  : inscripcion.estado === "rechazado"
                    ? "bg-red-500/20 text-red-500"
                    : "bg-yellow-400/20 text-yellow-400"
              }
            >
              {inscripcion.estado}
            </Badge>
          </div>

          {/* Personal Info */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-yellow-400">Información Personal</h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-gray-400">Nombre Completo</p>
                <p className="text-white font-medium">
                  {inscripcion.nombres} {inscripcion.apellidos}
                </p>
              </div>
              <div>
                <p className="text-gray-400">Cédula</p>
                <p className="text-white font-medium">{inscripcion.cedula}</p>
              </div>
              <div>
                <p className="text-gray-400">Email</p>
                <p className="text-white font-medium">{inscripcion.email}</p>
              </div>
              <div>
                <p className="text-gray-400">Teléfono</p>
                <p className="text-white font-medium">{inscripcion.telefono}</p>
              </div>
              <div>
                <p className="text-gray-400">Fecha de Nacimiento</p>
                <p className="text-white font-medium">{inscripcion.fechaNacimiento}</p>
              </div>
              {inscripcion.ciudad && (
                <div>
                  <p className="text-gray-400">Ciudad</p>
                  <p className="text-white font-medium">{inscripcion.ciudad}</p>
                </div>
              )}
            </div>
          </div>

          {/* Emergency Contact */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-yellow-400">Contacto de Emergencia</h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-gray-400">Nombre</p>
                <p className="text-white font-medium">{inscripcion.nombreEmergencia}</p>
              </div>
              <div>
                <p className="text-gray-400">Teléfono</p>
                <p className="text-white font-medium">{inscripcion.telefonoEmergencia}</p>
              </div>
            </div>
          </div>

          {/* Category & Medical */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-yellow-400">Categoría e Información Médica</h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-gray-400">Categoría</p>
                <p className="text-white font-medium capitalize">{inscripcion.categoria}</p>
              </div>
              <div>
                <p className="text-gray-400">Talla</p>
                <p className="text-white font-medium uppercase">{inscripcion.tallaCamiseta}</p>
              </div>
              <div>
                <p className="text-gray-400">Tipo de Sangre</p>
                <p className="text-white font-medium">{inscripcion.tipoSangre}</p>
              </div>
              {inscripcion.alergias && (
                <div className="col-span-2">
                  <p className="text-gray-400">Alergias</p>
                  <p className="text-white font-medium">{inscripcion.alergias}</p>
                </div>
              )}
              {inscripcion.condicionesMedicas && (
                <div className="col-span-2">
                  <p className="text-gray-400">Condiciones Médicas</p>
                  <p className="text-white font-medium">{inscripcion.condicionesMedicas}</p>
                </div>
              )}
            </div>
          </div>

          {/* Payment */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-yellow-400">Información de Pago</h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-gray-400">Método</p>
                <p className="text-white font-medium capitalize">{inscripcion.metodoPago?.replace("_", " ")}</p>
              </div>
              <div>
                <p className="text-gray-400">Referencia</p>
                <p className="text-white font-medium">{inscripcion.numeroReferencia}</p>
              </div>
            </div>

            {/* Payment Proof */}
            {inscripcion.comprobanteUrl && (
              <div className="space-y-2">
                <p className="text-gray-400">Comprobante de Pago</p>
                <div className="relative aspect-video bg-black rounded-lg overflow-hidden border border-yellow-400/20">
                  <Image
                    src={inscripcion.comprobanteUrl || "/placeholder.svg"}
                    alt="Comprobante de pago"
                    fill
                    className="object-contain"
                  />
                </div>
                <Button
                  variant="outline"
                  className="w-full border-yellow-400/50 text-yellow-400 hover:bg-yellow-400 hover:text-black bg-transparent"
                  asChild
                >
                  <a href={inscripcion.comprobanteUrl} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Ver en tamaño completo
                  </a>
                </Button>
              </div>
            )}
          </div>

          {/* Actions */}
          {inscripcion.estado === "pendiente" && (
            <div className="flex gap-4 pt-4 border-t border-yellow-400/20">
              <Button
                className="flex-1 bg-green-500 hover:bg-green-600 text-white"
                onClick={() => {
                  onApprove(inscripcion.id)
                  onClose()
                }}
              >
                <CheckCircle className="w-4 h-4 mr-2" />
                Aprobar Inscripción
              </Button>
              <Button
                variant="outline"
                className="flex-1 border-red-500/50 text-red-400 hover:bg-red-500 hover:text-white bg-transparent"
                onClick={() => {
                  onReject(inscripcion.id)
                  onClose()
                }}
              >
                <XCircle className="w-4 h-4 mr-2" />
                Rechazar
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
