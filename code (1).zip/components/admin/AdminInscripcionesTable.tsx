"use client"

import { useState } from "react"
import { doc, updateDoc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { Eye, CheckCircle, XCircle } from "lucide-react"
import InscripcionDetailModal from "./InscripcionDetailModal"
// import { emailService } from "@/lib/emailService"

interface AdminInscripcionesTableProps {
  inscripciones: any[]
}

export default function AdminInscripcionesTable({ inscripciones }: AdminInscripcionesTableProps) {
  const { toast } = useToast()
  const [selectedInscripcion, setSelectedInscripcion] = useState<any>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const handleApprove = async (id: string) => {
    try {
      const inscripcion = inscripciones.find((i) => i.id === id)

      await updateDoc(doc(db, "inscripciones", id), {
        estado: "aprobado",
        aprobadoPorAdmin: true,
      })

      // if (inscripcion) {
      //   await emailService.sendApprovalEmail({
      //     email: inscripcion.email,
      //     name: `${inscripcion.nombres} ${inscripcion.apellidos}`,
      //     cedula: inscripcion.cedula,
      //     categoria: inscripcion.categoria,
      //     tallaCamiseta: inscripcion.tallaCamiseta,
      //   })
      // }

      toast({
        title: "Inscripción aprobada",
        description: "El participante ha sido aprobado exitosamente",
      })
    } catch (error) {
      console.error("[v0] Error approving inscription:", error)
      toast({
        title: "Error",
        description: "No se pudo aprobar la inscripción",
        variant: "destructive",
      })
    }
  }

  const handleReject = async (id: string) => {
    try {
      const inscripcion = inscripciones.find((i) => i.id === id)

      await updateDoc(doc(db, "inscripciones", id), {
        estado: "rechazado",
      })

      // if (inscripcion) {
      //   await emailService.sendRejectionEmail({
      //     email: inscripcion.email,
      //     name: `${inscripcion.nombres} ${inscripcion.apellidos}`,
      //   })
      // }

      toast({
        title: "Inscripción rechazada",
        description: "El participante ha sido rechazado",
      })
    } catch (error) {
      console.error("[v0] Error rejecting inscription:", error)
      toast({
        title: "Error",
        description: "No se pudo rechazar la inscripción",
        variant: "destructive",
      })
    }
  }

  const getStatusBadge = (estado: string) => {
    switch (estado) {
      case "pendiente":
        return <Badge className="bg-yellow-400/20 text-yellow-400 border-none">Pendiente</Badge>
      case "aprobado":
        return <Badge className="bg-green-500/20 text-green-500 border-none">Aprobado</Badge>
      case "rechazado":
        return <Badge className="bg-red-500/20 text-red-500 border-none">Rechazado</Badge>
      default:
        return <Badge className="bg-gray-500/20 text-gray-500 border-none">{estado}</Badge>
    }
  }

  if (inscripciones.length === 0) {
    return (
      <div className="text-center py-12 text-gray-400">
        <p>No hay inscripciones en esta categoría</p>
      </div>
    )
  }

  return (
    <>
      <div className="rounded-lg border border-yellow-400/20 overflow-hidden">
        <Table>
          <TableHeader className="bg-zinc-900">
            <TableRow className="border-yellow-400/20 hover:bg-zinc-900">
              <TableHead className="text-yellow-400">Nombre</TableHead>
              <TableHead className="text-yellow-400">Email</TableHead>
              <TableHead className="text-yellow-400">Categoría</TableHead>
              <TableHead className="text-yellow-400">Estado</TableHead>
              <TableHead className="text-yellow-400 text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {inscripciones.map((inscripcion) => (
              <TableRow key={inscripcion.id} className="border-yellow-400/10 hover:bg-zinc-900/50">
                <TableCell className="text-white font-medium">
                  {inscripcion.nombres} {inscripcion.apellidos}
                </TableCell>
                <TableCell className="text-gray-400">{inscripcion.email}</TableCell>
                <TableCell className="text-gray-400 capitalize">{inscripcion.categoria}</TableCell>
                <TableCell>{getStatusBadge(inscripcion.estado)}</TableCell>
                <TableCell className="text-right">
                  <div className="flex gap-2 justify-end">
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-blue-500/50 text-blue-400 hover:bg-blue-500 hover:text-white bg-transparent"
                      onClick={() => {
                        setSelectedInscripcion(inscripcion)
                        setIsModalOpen(true)
                      }}
                    >
                      <Eye className="w-4 h-4" />
                    </Button>
                    {inscripcion.estado === "pendiente" && (
                      <>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-green-500/50 text-green-400 hover:bg-green-500 hover:text-white bg-transparent"
                          onClick={() => handleApprove(inscripcion.id)}
                        >
                          <CheckCircle className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-red-500/50 text-red-400 hover:bg-red-500 hover:text-white bg-transparent"
                          onClick={() => handleReject(inscripcion.id)}
                        >
                          <XCircle className="w-4 h-4" />
                        </Button>
                      </>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {selectedInscripcion && (
        <InscripcionDetailModal
          inscripcion={selectedInscripcion}
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onApprove={handleApprove}
          onReject={handleReject}
        />
      )}
    </>
  )
}
