"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, TrendingUp, DollarSign, Award } from "lucide-react"

interface AdminStatsProps {
  totalInscripciones: number
  aprobadas: number
  pendientes: number
  ingresos: number
}

export default function AdminStats({ totalInscripciones, aprobadas, pendientes, ingresos }: AdminStatsProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      <Card className="bg-gradient-to-br from-zinc-900 to-black border-yellow-400/20">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-sm font-medium text-gray-400">Total Inscripciones</CardTitle>
          <Users className="w-4 h-4 text-yellow-400" />
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-black text-white">{totalInscripciones}</div>
          <p className="text-xs text-gray-500 mt-1">Participantes totales</p>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-zinc-900 to-black border-yellow-400/20">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-sm font-medium text-gray-400">Aprobadas</CardTitle>
          <Award className="w-4 h-4 text-green-500" />
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-black text-green-500">{aprobadas}</div>
          <p className="text-xs text-gray-500 mt-1">Confirmados para el evento</p>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-zinc-900 to-black border-yellow-400/20">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-sm font-medium text-gray-400">Pendientes</CardTitle>
          <TrendingUp className="w-4 h-4 text-yellow-400" />
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-black text-yellow-400">{pendientes}</div>
          <p className="text-xs text-gray-500 mt-1">Esperando revisión</p>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-zinc-900 to-black border-yellow-400/20">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-sm font-medium text-gray-400">Ingresos</CardTitle>
          <DollarSign className="w-4 h-4 text-green-500" />
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-black text-green-500">${ingresos}</div>
          <p className="text-xs text-gray-500 mt-1">De inscripciones aprobadas</p>
        </CardContent>
      </Card>
    </div>
  )
}
