"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { collection, query, onSnapshot, orderBy } from "firebase/firestore"
import { auth, db } from "@/lib/firebase"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Users, Clock, CheckCircle, LogOut, DollarSign } from "lucide-react"
import { Button } from "@/components/ui/button"
import { signOut } from "firebase/auth"
import AdminInscripcionesTable from "@/components/admin/AdminInscripcionesTable"

export default function AdminDashboard() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [inscripciones, setInscripciones] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      if (!user) {
        router.push("/admin")
      } else {
        setUser(user)
      }
    })
    return () => unsubscribe()
  }, [router])

  useEffect(() => {
    if (!user) return

    const q = query(collection(db, "inscripciones"), orderBy("fechaInscripcion", "desc"))
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }))
      setInscripciones(data)
      setLoading(false)
    })

    return () => unsubscribe()
  }, [user])

  const handleLogout = async () => {
    await signOut(auth)
    router.push("/admin")
  }

  const pendientes = inscripciones.filter((i) => i.estado === "pendiente")
  const aprobadas = inscripciones.filter((i) => i.estado === "aprobado")
  const rechazadas = inscripciones.filter((i) => i.estado === "rechazado")

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-black via-zinc-900 to-black flex items-center justify-center">
        <div className="text-yellow-400 text-lg">Cargando...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-zinc-900 to-black">
      {/* Header */}
      <div className="border-b border-yellow-400/20 bg-black/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-black text-white">
                Panel de <span className="gradient-text">Administración</span>
              </h1>
              <p className="text-sm text-gray-400">Gestiona las inscripciones del evento</p>
            </div>
            <Button
              variant="outline"
              onClick={handleLogout}
              className="border-red-500/50 text-red-400 hover:bg-red-500 hover:text-white bg-transparent"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Cerrar Sesión
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-zinc-900 to-black border-yellow-400/20">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-400">Total Inscripciones</CardTitle>
              <Users className="w-4 h-4 text-yellow-400" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-black text-white">{inscripciones.length}</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-zinc-900 to-black border-yellow-400/20">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-400">Pendientes</CardTitle>
              <Clock className="w-4 h-4 text-yellow-400" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-black text-yellow-400">{pendientes.length}</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-zinc-900 to-black border-yellow-400/20">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-400">Aprobadas</CardTitle>
              <CheckCircle className="w-4 h-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-black text-green-500">{aprobadas.length}</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-zinc-900 to-black border-yellow-400/20">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-400">Ingresos</CardTitle>
              <DollarSign className="w-4 h-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-black text-green-500">${aprobadas.length * 50}</div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Card className="bg-black/50 border-yellow-400/20 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white">Gestión de Inscripciones</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="todas" className="w-full">
              <TabsList className="bg-zinc-900 border border-yellow-400/20">
                <TabsTrigger value="todas" className="data-[state=active]:bg-yellow-400 data-[state=active]:text-black">
                  Todas ({inscripciones.length})
                </TabsTrigger>
                <TabsTrigger
                  value="pendientes"
                  className="data-[state=active]:bg-yellow-400 data-[state=active]:text-black"
                >
                  Pendientes ({pendientes.length})
                </TabsTrigger>
                <TabsTrigger
                  value="aprobadas"
                  className="data-[state=active]:bg-yellow-400 data-[state=active]:text-black"
                >
                  Aprobadas ({aprobadas.length})
                </TabsTrigger>
                <TabsTrigger
                  value="rechazadas"
                  className="data-[state=active]:bg-yellow-400 data-[state=active]:text-black"
                >
                  Rechazadas ({rechazadas.length})
                </TabsTrigger>
              </TabsList>

              <TabsContent value="todas" className="mt-6">
                <AdminInscripcionesTable inscripciones={inscripciones} />
              </TabsContent>
              <TabsContent value="pendientes" className="mt-6">
                <AdminInscripcionesTable inscripciones={pendientes} />
              </TabsContent>
              <TabsContent value="aprobadas" className="mt-6">
                <AdminInscripcionesTable inscripciones={aprobadas} />
              </TabsContent>
              <TabsContent value="rechazadas" className="mt-6">
                <AdminInscripcionesTable inscripciones={rechazadas} />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
