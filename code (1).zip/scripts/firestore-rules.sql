rules_version = '2';

service cloud.firestore {
  match /databases/{database}/documents {
    
    // Inscripciones collection rules
    match /inscripciones/{inscripcionId} {
      // Allow anyone to create a new inscription (public registration)
      allow create: if true;
      
      // Allow authenticated users to read inscriptions
      allow read: if request.auth != null;
      
      // Only authenticated users can update/delete
      // In production, you should verify admin role here
      allow update, delete: if request.auth != null;
    }
    
    // Admin collection (optional - for storing admin user IDs)
    match /admins/{adminId} {
      allow read: if request.auth != null;
      allow write: if false; // Only manually add admins through Firebase console
    }
    
    // Default deny all other collections
    match /{document=**} {
      allow read, write: if false;
    }
  }
}
