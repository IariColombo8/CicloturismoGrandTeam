"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useFirebaseContext } from "@/components/providers/FirebaseProvider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Settings } from "lucide-react"
import ConfiguracionInicio from "@/components/admin/ConfiguracionInicio"
import ConfiguracionFormulario from "@/components/admin/ConfiguracionFormulario"

export default function ConfiguracionesPage() {
  const router = useRouter()
  const { user, userRole, loading } = useFirebaseContext()
  const [checking, setChecking] = useState(true)

  useEffect(() => {
    if (!loading) {
      if (!user) {
        router.push("/login")
      } else if (userRole !== "admin") {
        router.push("/")
      } else {
        setChecking(false)
      }
    }
  }, [user, userRole, loading, router])

  if (loading || checking) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-800 flex items-center justify-center">
        <div className="text-yellow-400 text-xl">Cargando...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-800 p-6 pt-28">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <Settings className="w-10 h-10 text-yellow-400" />
          <h1 className="text-4xl font-bold text-yellow-400">Configuraciones</h1>
        </div>

        <Tabs defaultValue="inicio" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-gray-800/50 border border-yellow-400/20">
            <TabsTrigger value="inicio" className="data-[state=active]:bg-yellow-400 data-[state=active]:text-black">
              Configuración de Inicio
            </TabsTrigger>
            <TabsTrigger
              value="formulario"
              className="data-[state=active]:bg-yellow-400 data-[state=active]:text-black"
            >
              Editor de Formularios
            </TabsTrigger>
          </TabsList>

          <TabsContent value="inicio" className="mt-6">
            <ConfiguracionInicio />
          </TabsContent>

          <TabsContent value="formulario" className="mt-6">
            <ConfiguracionFormulario />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
