"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { collection, query, onSnapshot, orderBy, getDocs, where, updateDoc, doc } from "firebase/firestore"
import { auth, db } from "@/lib/firebase"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Users, LogOut, CheckCircle, Clock, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { signOut } from "firebase/auth"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

export default function RegistroInscripciones() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [inscripciones, setInscripciones] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [isAuthorized, setIsAuthorized] = useState(false)
  const [selectedInscripcion, setSelectedInscripcion] = useState<any>(null)
  const [actionDialog, setActionDialog] = useState<{ open: boolean; action: string; id: string }>({
    open: false,
    action: "",
    id: "",
  })

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (user) => {
      if (!user) {
        router.push("/login?returnUrl=/admin/registro-inscripciones")
      } else {
        try {
          const adminRef = collection(db, "administrador")
          const adminQuery = query(adminRef, where("email", "==", user.email))
          const adminSnapshot = await getDocs(adminQuery)

          if (!adminSnapshot.empty) {
            const adminData = adminSnapshot.docs[0].data()

            if (adminData.role === "admin" || adminData.role === "grandteam") {
              setIsAuthorized(true)
              setUser(user)
            } else {
              router.push("/")
            }
          } else {
            router.push("/")
          }
        } catch (error) {
          console.error("Error verificando permisos:", error)
          router.push("/")
        }
      }
    })
    return () => unsubscribe()
  }, [router])

  useEffect(() => {
  if (!user) return

  const q = query(collection(db, "inscripciones"), orderBy("fechaInscripcion", "desc"))
  const unsubscribe = onSnapshot(q, (snapshot) => {
    const data = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }))
    setInscripciones(data)
    
    
    setLoading(false)
  })

  return () => unsubscribe()
}, [user])

  const handleLogout = async () => {
    await signOut(auth)
    router.push("/")
  }

  const handleChangeStatus = async (newStatus: string) => {
    if (!actionDialog.id) return

    try {
      const inscripcionRef = doc(db, "I_2026", actionDialog.id)
      await updateDoc(inscripcionRef, { estado: newStatus })
      setActionDialog({ open: false, action: "", id: "" })
    } catch (error) {
      console.error("Error actualizando estado:", error)
    }
  }

  const pendientes = inscripciones.filter((i) => i.estado === "pendiente")
  const confirmadas = inscripciones.filter((i) => i.estado === "confirmada")
  const rechazadas = inscripciones.filter((i) => i.estado === "rechazada")

  if (loading || !isAuthorized) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-black via-zinc-900 to-black flex items-center justify-center">
        <div className="text-yellow-400 text-lg">Cargando...</div>
      </div>
    )
  }

  const renderInscripcionesTable = (data: any[]) => (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="border-yellow-400/20 hover:bg-zinc-800/50">
            <TableHead className="text-yellow-400">Nombre</TableHead>
            <TableHead className="text-yellow-400">Email</TableHead>
            <TableHead className="text-yellow-400">Teléfono</TableHead>
            <TableHead className="text-yellow-400">Localidad</TableHead>
            <TableHead className="text-yellow-400">Estado</TableHead>
            <TableHead className="text-yellow-400 text-right">Acciones</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.map((inscripcion) => (
            <TableRow key={inscripcion.id} className="border-zinc-800 hover:bg-zinc-900/50">
              <TableCell className="text-white font-medium">
                {inscripcion.nombre} {inscripcion.apellido}
              </TableCell>
              <TableCell className="text-gray-400">{inscripcion.email}</TableCell>
              <TableCell className="text-gray-400">{inscripcion.telefono}</TableCell>
              <TableCell className="text-gray-400">{inscripcion.localidad}</TableCell>
              <TableCell>
                <span
                  className={`px-2 py-1 rounded text-xs font-semibold ${
                    inscripcion.estado === "confirmada"
                      ? "bg-green-500/20 text-green-400"
                      : inscripcion.estado === "pendiente"
                        ? "bg-yellow-500/20 text-yellow-400"
                        : "bg-red-500/20 text-red-400"
                  }`}
                >
                  {inscripcion.estado.toUpperCase()}
                </span>
              </TableCell>
              <TableCell className="text-right space-x-2">
                <Button
                  size="sm"
                  onClick={() => setSelectedInscripcion(inscripcion)}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  Ver
                </Button>
                {inscripcion.estado !== "confirmada" && (
                  <Button
                    size="sm"
                    onClick={() => {
                      setActionDialog({
                        open: true,
                        action: "confirmar",
                        id: inscripcion.id,
                      })
                    }}
                    className="bg-green-600 hover:bg-green-700 text-white"
                  >
                    <CheckCircle className="w-4 h-4" />
                  </Button>
                )}
                {inscripcion.estado !== "rechazada" && (
                  <Button
                    size="sm"
                    onClick={() => {
                      setActionDialog({
                        open: true,
                        action: "rechazar",
                        id: inscripcion.id,
                      })
                    }}
                    className="bg-red-600 hover:bg-red-700 text-white"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      {data.length === 0 && (
        <div className="text-center py-8 text-gray-400">No hay inscripciones en esta categoría</div>
      )}
    </div>
  )

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-zinc-900 to-black">
      {/* Header */}
      <div className="border-b border-yellow-400/20 bg-black/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-black text-white">
                Registro de <span className="gradient-text">Inscripciones</span>
              </h1>
              <p className="text-sm text-gray-400">Gestiona todas las inscripciones del evento</p>
            </div>
            <Button
              variant="outline"
              onClick={handleLogout}
              className="border-red-500/50 text-red-400 hover:bg-red-500 hover:text-white bg-transparent"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Cerrar Sesión
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-zinc-900 to-black border-yellow-400/20">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-400">Pendientes</CardTitle>
              <Clock className="w-4 h-4 text-yellow-400" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-black text-yellow-400">{pendientes.length}</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-zinc-900 to-black border-yellow-400/20">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-400">Confirmadas</CardTitle>
              <CheckCircle className="w-4 h-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-black text-green-500">{confirmadas.length}</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-zinc-900 to-black border-yellow-400/20">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-400">Total</CardTitle>
              <Users className="w-4 h-4 text-blue-400" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-black text-blue-400">{inscripciones.length}</div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Card className="bg-black/50 border-yellow-400/20 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white">Listado de Inscripciones</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="todas" className="w-full">
              <TabsList className="bg-zinc-900 border border-yellow-400/20">
                <TabsTrigger value="todas" className="data-[state=active]:bg-yellow-400 data-[state=active]:text-black">
                  Todas ({inscripciones.length})
                </TabsTrigger>
                <TabsTrigger
                  value="pendientes"
                  className="data-[state=active]:bg-yellow-400 data-[state=active]:text-black"
                >
                  Pendientes ({pendientes.length})
                </TabsTrigger>
                <TabsTrigger
                  value="confirmadas"
                  className="data-[state=active]:bg-yellow-400 data-[state=active]:text-black"
                >
                  Confirmadas ({confirmadas.length})
                </TabsTrigger>
                <TabsTrigger
                  value="rechazadas"
                  className="data-[state=active]:bg-yellow-400 data-[state=active]:text-black"
                >
                  Rechazadas ({rechazadas.length})
                </TabsTrigger>
              </TabsList>

              <TabsContent value="todas" className="mt-6">
                {renderInscripcionesTable(inscripciones)}
              </TabsContent>
              <TabsContent value="pendientes" className="mt-6">
                {renderInscripcionesTable(pendientes)}
              </TabsContent>
              <TabsContent value="confirmadas" className="mt-6">
                {renderInscripcionesTable(confirmadas)}
              </TabsContent>
              <TabsContent value="rechazadas" className="mt-6">
                {renderInscripcionesTable(rechazadas)}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>

      {/* Action Dialog */}
      <AlertDialog open={actionDialog.open} onOpenChange={(open) => setActionDialog({ ...actionDialog, open })}>
        <AlertDialogContent className="bg-zinc-900 border-yellow-400/20">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white">
              {actionDialog.action === "confirmar" ? "Confirmar Inscripción" : "Rechazar Inscripción"}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-gray-400">
              {actionDialog.action === "confirmar"
                ? "¿Estás seguro de que deseas confirmar esta inscripción?"
                : "¿Estás seguro de que deseas rechazar esta inscripción?"}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="flex gap-3">
            <AlertDialogCancel className="bg-zinc-800 text-white border-0 hover:bg-zinc-700">
              Cancelar
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => handleChangeStatus(actionDialog.action === "confirmar" ? "confirmada" : "rechazada")}
              className={`${
                actionDialog.action === "confirmar" ? "bg-green-600 hover:bg-green-700" : "bg-red-600 hover:bg-red-700"
              } text-white border-0`}
            >
              {actionDialog.action === "confirmar" ? "Confirmar" : "Rechazar"}
            </AlertDialogAction>
          </div>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
