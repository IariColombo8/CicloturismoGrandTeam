import emailjs from "@emailjs/browser"

// Configuración de EmailJS (se debe configurar en Firebase o .env)
const SERVICE_ID = process.env.NEXT_PUBLIC_EMAILJS_SERVICE_ID || "your_service_id"
const TEMPLATE_ID = process.env.NEXT_PUBLIC_EMAILJS_TEMPLATE_ID || "your_template_id"
const PUBLIC_KEY = process.env.NEXT_PUBLIC_EMAILJS_PUBLIC_KEY || "your_public_key"

export const emailService = {
  async sendConfirmationEmail(data: {
    email: string
    nombreCompleto: string
    eventoNombre: string
    fechaEvento: string
    ubicacion: string
  }) {
    try {
      const templateParams = {
        to_email: data.email,
        to_name: data.nombreCompleto,
        evento_nombre: data.eventoNombre,
        fecha_evento: data.fechaEvento,
        ubicacion: data.ubicacion,
        mensaje: `¡Tu inscripción ha sido confirmada! Te esperamos el ${data.fechaEvento} en ${data.ubicacion}.`,
      }

      const response = await emailjs.send(SERVICE_ID, TEMPLATE_ID, templateParams, PUBLIC_KEY)

      console.log("[v0] Email enviado exitosamente:", response)
      return { success: true, response }
    } catch (error) {
      console.error("[v0] Error enviando email:", error)
      return { success: false, error }
    }
  },

  async sendRejectionEmail(data: {
    email: string
    nombreCompleto: string
    motivo?: string
  }) {
    try {
      const templateParams = {
        to_email: data.email,
        to_name: data.nombreCompleto,
        mensaje: `Lamentablemente tu inscripción no ha sido aprobada. ${data.motivo || "Por favor contacta con los organizadores para más información."}`,
      }

      const response = await emailjs.send(SERVICE_ID, TEMPLATE_ID, templateParams, PUBLIC_KEY)

      return { success: true, response }
    } catch (error) {
      console.error("[v0] Error enviando email de rechazo:", error)
      return { success: false, error }
    }
  },
}
