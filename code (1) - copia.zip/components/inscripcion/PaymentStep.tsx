"use client"

import type React from "react"

import { useState } from "react"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"
import { Upload, FileCheck, DollarSign, CreditCard, Smartphone } from "lucide-react"

interface PaymentStepProps {
  formData: any
  updateFormData: (data: any) => void
}

export default function PaymentStep({ formData, updateFormData }: PaymentStepProps) {
  const [fileName, setFileName] = useState<string>("")

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      updateFormData({ comprobanteFile: file })
      setFileName(file.name)
    }
  }

  const paymentMethods = [
    { value: "transferencia", label: "Transferencia Bancaria", icon: CreditCard },
    { value: "deposito", label: "Depósito Bancario", icon: DollarSign },
    { value: "pago_movil", label: "Pago Móvil", icon: Smartphone },
  ]

  return (
    <div className="space-y-6">
      {/* Payment Amount */}
      <Card className="bg-gradient-to-r from-yellow-400/10 to-amber-600/10 border-yellow-400/30">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">Costo de Inscripción</p>
              <p className="text-4xl font-black text-yellow-400">$50 USD</p>
              <p className="text-gray-500 text-sm mt-1">Incluye kit completo del evento</p>
            </div>
            <DollarSign className="w-16 h-16 text-yellow-400/30" />
          </div>
        </CardContent>
      </Card>

      {/* Payment Method */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-yellow-400">Método de Pago</h3>

        <div className="space-y-2">
          <Label htmlFor="metodoPago" className="text-gray-300">
            Selecciona tu método de pago <span className="text-red-500">*</span>
          </Label>
          <Select value={formData.metodoPago} onValueChange={(value) => updateFormData({ metodoPago: value })}>
            <SelectTrigger className="bg-zinc-900 border-yellow-400/30 text-white">
              <SelectValue placeholder="Elige un método de pago" />
            </SelectTrigger>
            <SelectContent className="bg-zinc-900 border-yellow-400/30">
              {paymentMethods.map((method) => (
                <SelectItem key={method.value} value={method.value}>
                  {method.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Bank Details */}
        {formData.metodoPago && (
          <Card className="bg-zinc-900 border-yellow-400/20 mt-4">
            <CardContent className="p-4">
              <h4 className="text-white font-semibold mb-3">Datos Bancarios</h4>
              <div className="space-y-2 text-sm text-gray-300">
                <p>
                  <strong className="text-yellow-400">Banco:</strong> Banco Nacional
                </p>
                <p>
                  <strong className="text-yellow-400">Cuenta:</strong> 1234-5678-9012-3456
                </p>
                <p>
                  <strong className="text-yellow-400">Titular:</strong> Grand Team Bike Events
                </p>
                <p>
                  <strong className="text-yellow-400">RIF/ID:</strong> J-12345678-9
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Reference Number */}
      <div className="space-y-2">
        <Label htmlFor="numeroReferencia" className="text-gray-300">
          Número de Referencia <span className="text-red-500">*</span>
        </Label>
        <Input
          id="numeroReferencia"
          value={formData.numeroReferencia}
          onChange={(e) => updateFormData({ numeroReferencia: e.target.value })}
          placeholder="Ej: 123456789012"
          className="bg-zinc-900 border-yellow-400/30 text-white"
          required
        />
        <p className="text-sm text-gray-500">Ingresa el número de confirmación de tu pago</p>
      </div>

      {/* Upload Proof */}
      <div className="space-y-2">
        <Label htmlFor="comprobante" className="text-gray-300">
          Comprobante de Pago <span className="text-red-500">*</span>
        </Label>
        <div className="relative">
          <input id="comprobante" type="file" accept="image/*,.pdf" onChange={handleFileChange} className="hidden" />
          <label
            htmlFor="comprobante"
            className="flex items-center justify-center gap-3 p-6 bg-zinc-900 border-2 border-dashed border-yellow-400/30 rounded-lg cursor-pointer hover:border-yellow-400/50 hover:bg-zinc-800/50 transition-all"
          >
            {fileName ? (
              <>
                <FileCheck className="w-6 h-6 text-green-500" />
                <span className="text-white">{fileName}</span>
              </>
            ) : (
              <>
                <Upload className="w-6 h-6 text-yellow-400" />
                <span className="text-gray-400">Haz clic para subir tu comprobante</span>
              </>
            )}
          </label>
        </div>
        <p className="text-sm text-gray-500">Formatos aceptados: JPG, PNG, PDF (Máx. 5MB)</p>
      </div>

      {/* Important Notice */}
      <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
        <p className="text-sm text-gray-300">
          <strong className="text-blue-400">Importante:</strong> Tu inscripción será revisada por nuestro equipo
          administrativo. Recibirás un correo de confirmación una vez aprobado el pago. Esto puede tomar entre 24-48
          horas.
        </p>
      </div>
    </div>
  )
}
