"use client"

import { useState, useEffect } from "react"
import { doc, getDoc, setDoc, serverTimestamp, collection, getDocs } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { Save, Plus, Trash2, GripVertical, ChevronDown, ChevronUp } from "lucide-react"
import type { FormField, FieldType } from "@/types/form-builder"
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd"

export default function ConfiguracionFormulario() {
  const { toast } = useToast()
  const [saving, setSaving] = useState(false)
  const [loading, setLoading] = useState(true)

  const [selectedYear, setSelectedYear] = useState("2026")
  const [formTitle, setFormTitle] = useState("")
  const [formDescription, setFormDescription] = useState("")
  const [fields, setFields] = useState<FormField[]>([])
  const [availableYears, setAvailableYears] = useState<string[]>([])

  useEffect(() => {
    loadAvailableYears()
  }, [])

  useEffect(() => {
    if (selectedYear) {
      loadFormConfig(selectedYear)
    }
  }, [selectedYear])

  const loadAvailableYears = async () => {
    try {
      const formCollectionRef = collection(db, "Formulario")
      const snapshot = await getDocs(formCollectionRef)
      const years = snapshot.docs.map((doc) => doc.id)

      if (!years.includes("2026")) {
        years.push("2026")
      }

      setAvailableYears(years.sort().reverse())
    } catch (error) {
      console.error("[v0] Error loading years:", error)
      setAvailableYears(["2026"])
    } finally {
      setLoading(false)
    }
  }

  const loadFormConfig = async (year: string) => {
    try {
      const docRef = doc(db, "Formulario", year)
      const docSnap = await getDoc(docRef)

      if (docSnap.exists()) {
        const data = docSnap.data()
        setFormTitle(data.title || "")
        setFormDescription(data.description || "")
        setFields(data.fields || [])
      } else {
        // Set default values for new year
        setFormTitle(`Formulario de Inscripción ${year}`)
        setFormDescription("Completa el siguiente formulario para inscribirte al evento")
        setFields([])
      }
    } catch (error) {
      console.error("[v0] Error loading form config:", error)
    }
  }

  const addField = () => {
    const newField: FormField = {
      id: `field_${Date.now()}`,
      type: "text",
      label: "Nueva Pregunta",
      placeholder: "",
      required: false,
      options: [],
      order: fields.length,
    }
    setFields([...fields, newField])
  }

  const updateField = (id: string, updates: Partial<FormField>) => {
    setFields(fields.map((field) => (field.id === id ? { ...field, ...updates } : field)))
  }

  const deleteField = (id: string) => {
    setFields(fields.filter((field) => field.id !== id))
  }

  const onDragEnd = (result: any) => {
    if (!result.destination) return

    const items = Array.from(fields)
    const [reorderedItem] = items.splice(result.source.index, 1)
    items.splice(result.destination.index, 0, reorderedItem)

    // Update order property
    const updatedItems = items.map((item, index) => ({ ...item, order: index }))
    setFields(updatedItems)
  }

  const handleSave = async () => {
    if (!formTitle) {
      toast({
        title: "Error",
        description: "Por favor ingresa un título para el formulario",
        variant: "destructive",
      })
      return
    }

    setSaving(true)

    try {
      const formData = {
        year: Number.parseInt(selectedYear),
        title: formTitle,
        description: formDescription,
        fields: fields,
        active: true,
        updatedAt: serverTimestamp(),
      }

      await setDoc(doc(db, "Formulario", selectedYear), formData, { merge: true })

      toast({
        title: "Formulario guardado",
        description: `El formulario para ${selectedYear} se ha guardado exitosamente`,
      })

      // Reload available years in case a new year was created
      loadAvailableYears()
    } catch (error) {
      console.error("[v0] Error saving form config:", error)
      toast({
        title: "Error",
        description: "No se pudo guardar el formulario",
        variant: "destructive",
      })
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <Card className="bg-gray-800/50 border-yellow-400/20">
        <CardContent className="p-12 text-center">
          <p className="text-gray-400">Cargando...</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800/50 border-yellow-400/20">
        <CardHeader>
          <CardTitle className="text-yellow-400">Editor de Formularios</CardTitle>
          <CardDescription className="text-gray-400">
            Crea y personaliza los campos del formulario de inscripción por año
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Year Selector */}
          <div>
            <Label className="text-gray-300">Año del Formulario</Label>
            <div className="flex gap-2">
              <Select value={selectedYear} onValueChange={setSelectedYear}>
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {availableYears.map((year) => (
                    <SelectItem key={year} value={year}>
                      {year}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                onClick={() => {
                  const newYear = prompt("Ingresa el año del nuevo formulario:")
                  if (newYear && !availableYears.includes(newYear)) {
                    setSelectedYear(newYear)
                    setAvailableYears([...availableYears, newYear].sort().reverse())
                  }
                }}
                variant="outline"
                className="border-yellow-400/50 text-yellow-400 hover:bg-yellow-400 hover:text-black"
              >
                <Plus className="w-4 h-4 mr-2" />
                Nuevo Año
              </Button>
            </div>
          </div>

          {/* Form Title & Description */}
          <div>
            <Label className="text-gray-300">Título del Formulario</Label>
            <Input
              value={formTitle}
              onChange={(e) => setFormTitle(e.target.value)}
              placeholder="Formulario de Inscripción 2026"
              className="bg-gray-700 border-gray-600 text-white"
            />
          </div>

          <div>
            <Label className="text-gray-300">Descripción</Label>
            <Textarea
              value={formDescription}
              onChange={(e) => setFormDescription(e.target.value)}
              placeholder="Descripción del formulario"
              className="bg-gray-700 border-gray-600 text-white"
              rows={2}
            />
          </div>
        </CardContent>
      </Card>

      {/* Fields List */}
      <Card className="bg-gray-800/50 border-yellow-400/20">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-yellow-400">Campos del Formulario</CardTitle>
              <CardDescription className="text-gray-400">Arrastra para reordenar los campos</CardDescription>
            </div>
            <Button
              onClick={addField}
              className="bg-gradient-to-r from-yellow-400 to-yellow-600 text-black hover:from-yellow-500 hover:to-yellow-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Agregar Campo
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {fields.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <p>No hay campos en el formulario</p>
              <p className="text-sm mt-2">Haz clic en "Agregar Campo" para comenzar</p>
            </div>
          ) : (
            <DragDropContext onDragEnd={onDragEnd}>
              <Droppable droppableId="fields">
                {(provided) => (
                  <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-4">
                    {fields.map((field, index) => (
                      <Draggable key={field.id} draggableId={field.id} index={index}>
                        {(provided) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            className="bg-gray-700/50 border border-gray-600 rounded-lg p-4"
                          >
                            <FormFieldEditor
                              field={field}
                              onUpdate={(updates) => updateField(field.id, updates)}
                              onDelete={() => deleteField(field.id)}
                              dragHandleProps={provided.dragHandleProps}
                            />
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            </DragDropContext>
          )}
        </CardContent>
      </Card>

      {/* Save Button */}
      <Button
        onClick={handleSave}
        disabled={saving}
        className="w-full bg-gradient-to-r from-green-500 to-green-600 text-white hover:from-green-600 hover:to-green-700"
      >
        <Save className="w-4 h-4 mr-2" />
        {saving ? "Guardando..." : "Guardar Formulario"}
      </Button>
    </div>
  )
}

interface FormFieldEditorProps {
  field: FormField
  onUpdate: (updates: Partial<FormField>) => void
  onDelete: () => void
  dragHandleProps: any
}

function FormFieldEditor({ field, onUpdate, onDelete, dragHandleProps }: FormFieldEditorProps) {
  const [expanded, setExpanded] = useState(false)

  const fieldTypeLabels: Record<FieldType, string> = {
    text: "Texto corto",
    textarea: "Texto largo",
    email: "Email",
    number: "Número",
    date: "Fecha",
    select: "Lista desplegable",
    radio: "Opción múltiple",
    checkbox: "Casillas de verificación",
    file: "Archivo",
  }

  const requiresOptions = ["select", "radio", "checkbox"].includes(field.type)

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div {...dragHandleProps} className="cursor-grab text-gray-400 hover:text-yellow-400">
          <GripVertical className="w-5 h-5" />
        </div>

        <div className="flex-1">
          <Input
            value={field.label}
            onChange={(e) => onUpdate({ label: e.target.value })}
            placeholder="Etiqueta del campo"
            className="bg-gray-600 border-gray-500 text-white font-medium"
          />
        </div>

        <Button
          size="sm"
          variant="ghost"
          onClick={() => setExpanded(!expanded)}
          className="text-gray-400 hover:text-yellow-400"
        >
          {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </Button>

        <Button
          size="sm"
          variant="ghost"
          onClick={onDelete}
          className="text-red-400 hover:text-red-300 hover:bg-red-500/20"
        >
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>

      {/* Expanded Options */}
      {expanded && (
        <div className="ml-8 space-y-3 border-l-2 border-yellow-400/30 pl-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-gray-300 text-sm">Tipo de Campo</Label>
              <Select value={field.type} onValueChange={(value) => onUpdate({ type: value as FieldType })}>
                <SelectTrigger className="bg-gray-600 border-gray-500 text-white text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(fieldTypeLabels).map(([value, label]) => (
                    <SelectItem key={value} value={value}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-gray-300 text-sm">Placeholder (opcional)</Label>
              <Input
                value={field.placeholder || ""}
                onChange={(e) => onUpdate({ placeholder: e.target.value })}
                placeholder="Texto de ejemplo..."
                className="bg-gray-600 border-gray-500 text-white text-sm"
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id={`required-${field.id}`}
              checked={field.required}
              onChange={(e) => onUpdate({ required: e.target.checked })}
              className="w-4 h-4 rounded border-gray-500 text-yellow-400 focus:ring-yellow-400"
            />
            <Label htmlFor={`required-${field.id}`} className="text-gray-300 text-sm cursor-pointer">
              Campo obligatorio
            </Label>
          </div>

          {requiresOptions && (
            <div>
              <Label className="text-gray-300 text-sm">Opciones (una por línea)</Label>
              <Textarea
                value={(field.options || []).join("\n")}
                onChange={(e) =>
                  onUpdate({
                    options: e.target.value
                      .split("\n")
                      .map((o) => o.trim())
                      .filter(Boolean),
                  })
                }
                placeholder="Opción 1&#10;Opción 2&#10;Opción 3"
                className="bg-gray-600 border-gray-500 text-white text-sm"
                rows={4}
              />
            </div>
          )}
        </div>
      )}
    </div>
  )
}
