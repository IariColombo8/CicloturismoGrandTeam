"use client"

import { useState } from "react"
import { doc, updateDoc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { Eye, CheckCircle, XCircle, Download } from "lucide-react"
import InscripcionDetailModal from "./InscripcionDetailModal"
import { emailService } from "@/lib/emailService"
import { exportToExcel, formatInscripcionForExport } from "@/lib/exportUtils"

interface AdminInscripcionesTableProps {
  inscripciones: any[]
}

export default function AdminInscripcionesTable({ inscripciones }: AdminInscripcionesTableProps) {
  const { toast } = useToast()
  const [selectedInscripcion, setSelectedInscripcion] = useState<any>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const handleExportToExcel = () => {
    const dataToExport = inscripciones.map(formatInscripcionForExport)
    exportToExcel(dataToExport, `inscripciones_${new Date().toISOString().split("T")[0]}`)

    toast({
      title: "Exportación exitosa",
      description: `Se exportaron ${inscripciones.length} inscripciones`,
    })
  }

  const handleApprove = async (id: string) => {
    try {
      const inscripcion = inscripciones.find((i) => i.id === id)

      await updateDoc(doc(db, "inscripciones_2026", id), {
        estado: "confirmada",
        confirmadoPor: "admin",
        fechaConfirmacion: new Date(),
      })

      if (inscripcion) {
        const emailResult = await emailService.sendConfirmationEmail({
          email: inscripcion.email,
          nombreCompleto: inscripcion.nombreCompleto,
          eventoNombre: "Cicloturismo Grand Team Bike 2026",
          fechaEvento: "8 de Noviembre de 2026",
          ubicacion: "Concepción del Uruguay, Entre Ríos",
        })

        if (emailResult.success) {
          toast({
            title: "Inscripción confirmada",
            description: "Se ha enviado un email de confirmación al participante",
          })
        } else {
          toast({
            title: "Inscripción confirmada",
            description: "Inscripción aprobada, pero hubo un error al enviar el email",
            variant: "destructive",
          })
        }
      }
    } catch (error) {
      console.error("[v0] Error approving inscription:", error)
      toast({
        title: "Error",
        description: "No se pudo aprobar la inscripción",
        variant: "destructive",
      })
    }
  }

  const handleReject = async (id: string) => {
    const motivo = prompt("Motivo del rechazo (opcional):")
    if (motivo === null) return // User cancelled

    try {
      const inscripcion = inscripciones.find((i) => i.id === id)

      await updateDoc(doc(db, "inscripciones_2026", id), {
        estado: "rechazada",
        motivoRechazo: motivo,
      })

      if (inscripcion) {
        await emailService.sendRejectionEmail({
          email: inscripcion.email,
          nombreCompleto: inscripcion.nombreCompleto,
          motivo,
        })
      }

      toast({
        title: "Inscripción rechazada",
        description: "Se ha notificado al participante",
      })
    } catch (error) {
      console.error("[v0] Error rejecting inscription:", error)
      toast({
        title: "Error",
        description: "No se pudo rechazar la inscripción",
        variant: "destructive",
      })
    }
  }

  const getStatusBadge = (estado: string) => {
    switch (estado) {
      case "pendiente":
        return <Badge className="bg-yellow-400/20 text-yellow-400 border-none">Pendiente</Badge>
      case "confirmada":
        return <Badge className="bg-green-500/20 text-green-500 border-none">Confirmada</Badge>
      case "rechazada":
        return <Badge className="bg-red-500/20 text-red-500 border-none">Rechazada</Badge>
      default:
        return <Badge className="bg-gray-500/20 text-gray-500 border-none">{estado}</Badge>
    }
  }

  if (inscripciones.length === 0) {
    return (
      <div className="text-center py-12 text-gray-400">
        <p>No hay inscripciones en esta categoría</p>
      </div>
    )
  }

  return (
    <>
      <div className="flex justify-end mb-4">
        <Button
          onClick={handleExportToExcel}
          variant="outline"
          className="border-green-500/50 text-green-400 hover:bg-green-500 hover:text-white bg-transparent"
        >
          <Download className="w-4 h-4 mr-2" />
          Exportar a Excel ({inscripciones.length})
        </Button>
      </div>

      <div className="rounded-lg border border-yellow-400/20 overflow-hidden">
        <Table>
          <TableHeader className="bg-zinc-900">
            <TableRow className="border-yellow-400/20 hover:bg-zinc-900">
              <TableHead className="text-yellow-400">Nombre</TableHead>
              <TableHead className="text-yellow-400">Email</TableHead>
              <TableHead className="text-yellow-400">Teléfono</TableHead>
              <TableHead className="text-yellow-400">Localidad</TableHead>
              <TableHead className="text-yellow-400">Estado</TableHead>
              <TableHead className="text-yellow-400 text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {inscripciones.map((inscripcion) => (
              <TableRow key={inscripcion.id} className="border-yellow-400/10 hover:bg-zinc-900/50">
                <TableCell className="text-white font-medium">{inscripcion.nombreCompleto}</TableCell>
                <TableCell className="text-gray-400">{inscripcion.email}</TableCell>
                <TableCell className="text-gray-400">{inscripcion.telefono}</TableCell>
                <TableCell className="text-gray-400">{inscripcion.localidad}</TableCell>
                <TableCell>{getStatusBadge(inscripcion.estado)}</TableCell>
                <TableCell className="text-right">
                  <div className="flex gap-2 justify-end">
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-blue-500/50 text-blue-400 hover:bg-blue-500 hover:text-white bg-transparent"
                      onClick={() => {
                        setSelectedInscripcion(inscripcion)
                        setIsModalOpen(true)
                      }}
                    >
                      <Eye className="w-4 h-4" />
                    </Button>
                    {inscripcion.estado === "pendiente" && (
                      <>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-green-500/50 text-green-400 hover:bg-green-500 hover:text-white bg-transparent"
                          onClick={() => handleApprove(inscripcion.id)}
                        >
                          <CheckCircle className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-red-500/50 text-red-400 hover:bg-red-500 hover:text-white bg-transparent"
                          onClick={() => handleReject(inscripcion.id)}
                        >
                          <XCircle className="w-4 h-4" />
                        </Button>
                      </>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {selectedInscripcion && (
        <InscripcionDetailModal
          inscripcion={selectedInscripcion}
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onApprove={handleApprove}
          onReject={handleReject}
        />
      )}
    </>
  )
}
